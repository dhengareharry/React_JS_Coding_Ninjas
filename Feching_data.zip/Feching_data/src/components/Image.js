import React from "react";
import styles from "./image.module.css";

class Image extends React.Component {
  render() {
    const {photo}=this.props
    return (
      <div className={styles.imageContainer}>
        <img
          src={photo.url}
          alt={photo.title}
          height="100%"
          width="100%"
        />
      </div>
    );
  }
}

export default Image;
