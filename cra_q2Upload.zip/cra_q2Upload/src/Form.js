// Complete the Form Component and export it
import {name} from "./HomePage"
import {email}from "./HomePage"
const handleSubmit = (e) => {
  e.preventDefault();
}

export const Form = () => (
  <>
    <div>
      <h3>Login page</h3>
      <form onClick={handleSubmit}>{/* Create a h3, 2 inputs and 1 button here */}
      <div><input type="text" id="name"  value={name}/></div>
      <br/>
      <div><input type="email" id="email" value={email}/></div>
      <br/>
      <button>Login</button>
      </form>
    </div>
  </>
);


