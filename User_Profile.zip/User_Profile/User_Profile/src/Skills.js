import React from "react";

const Skills = () => {
  return (
    <div className="skills">
      <ul className="skills-list">
        <li className="skill">HTML</li>
        <li className="skill">CSS</li>
        <li className="skill">JavaScript</li>
        <li className="skill">React</li>
        <li className="skill">Node.js</li>
      </ul>
    </div>
  );
};

export default Skills;
