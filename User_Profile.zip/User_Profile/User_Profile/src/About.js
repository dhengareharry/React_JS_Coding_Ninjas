import React from "react";

const About = () => {
  return (
    <div className="about">
      <p>
        Hi, my name is Pranav. I am a full stack web developer and I have developed several projects with the MERN stack. I am also familiar with Python and Django.
      </p>
    </div>
  );
};

export default About;
