import React from "react";

const Hero = () => {
  return (
    <div className="hero">
      <h4>Name: Pranav Sharad Yeole</h4>
      <p>Email: pranav@google.com</p>
      <p>Phone: 8546465544</p>
      <p>Address: ABC, xyz street</p>
    </div>
  );
};

export default Hero;
