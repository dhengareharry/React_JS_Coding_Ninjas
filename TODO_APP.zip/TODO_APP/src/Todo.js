import { Component } from "react";

export class Todo extends Component {
  render() {
    const { todo, Remove } = this.props;
    return (
      <div className="todo">
        <p>{todo.text}</p>
        <button onClick={Remove}>x</button>
      </div>
    );
  }
}
